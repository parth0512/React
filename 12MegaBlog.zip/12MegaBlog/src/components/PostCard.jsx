import React from "react";
import { Link } from "react-router-dom";

function PostCard({ $id, title, featuredImage, content }) {
  return (
    <Link
      to={`/post/${$id}`}
      className="block hover:scale-[1.02] transition-all"
    >
      <div className="w-full bg-gray-100 rounded-xl p-4 h-full">
        {featuredImage && (
          <div className="w-full mb-4 aspect-video overflow-hidden">
            <img
              src={featuredImage}
              alt={title || "Post image"}
              className="rounded-xl w-full h-full object-cover"
            />
          </div>
        )}
        <h2 className="text-xl font-bold truncate">{title}</h2>
        {content && (
          <p className="mt-2 text-gray-600 line-clamp-3">
            {content.replace(/<[^>]+>/g, "")} {/* Remove HTML tags */}
          </p>
        )}
      </div>
    </Link>
  );
}

export default PostCard;
